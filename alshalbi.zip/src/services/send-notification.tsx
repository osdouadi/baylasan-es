"use server";

import { mailOptions, transporter } from "@/app/config/email";
import { htmlData } from "@/app/templates/notification";

type Data = {
  fullName: string;
  email?: string;
  phoneNumber?: string;
  userType?: string;
  contentType?: string;
  content: string;
};

export const sendNotification = async (data: Data) => {
  const html = htmlData
    .replace("{{ fullName }}", data.fullName || "")
    .replace("{{ email }}", data.email || "")
    .replace("{{ phoneNumber }}", data.phoneNumber || "")
    .replace("{{ userType }}", data.userType || "")
    .replace("{{ contentType }}", data.contentType || "")
    .replace("{{ content }}", data.content || "");

  await transporter.sendMail({
    ...mailOptions,
    subject: "لديك طلب جديد على متجرك",
    text: "You have a new Order",
    html,
  });
};
