export const htmlData = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Tajawal:wght@200;300;400;500;700;800;900&display=swap" rel="stylesheet">
    <title>لديك طلب جديد على متجرك</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Cairo', 'Tajawal', sans-serif;
        }

        body {
            font-family: 'Cairo', 'Tajawal', sans-serif;
            line-height: 1.6;
            background-color: #f9fafb;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        /* Header styling */
        .title-container {
            background: linear-gradient(45deg, #ec4899, #d946ef);
            padding: 20px;
            text-align: center;
            direction: rtl;
            font-family: 'Cairo', 'Tajawal', sans-serif;
            border-radius: 4px;
        }

        .title-container h1 {
            color: #ffffff;
            font-size: 20px;
            margin: 0;
            font-weight: 600;
        }

        /* Styling for content */
        ul {
            list-style: none;
            padding: 0;
            margin-top: 20px;
            direction: rtl;
        }

        .info-item {
            padding: 12px 0;
            border-bottom: 1px solid #f3f4f6;
            font-size: 16px;
            direction: rtl;
            text-align: right;
        }

        .info-item strong {
            color: #db2777;
        }

        /* Special styling for the "محتوى الرسالة" section */
        .content {
            padding: 10px 0;
            font-size: 16px;
        }

        .content-title {
            font-weight: bold;
            color: #db2777;
        }

        .content-text {
            display: block;
            margin-top: 6px;
            padding: 8px;
            border-radius: 6px;
            background-color: #f3f4f6;
            font-size: 14px;
            color: #333;
            text-align: right;
        }

        /* Responsive styles */
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
        }

        /* Styling buttons and hover effects */
        .cta-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #db2777;
            color: #ffffff;
            text-decoration: none;
            font-weight: 600;
            border-radius: 6px;
            text-align: center;
            transition: background 0.3s;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title-container">
            <h1> رسالة خدمة الدعم</h1>    
        </div>    
        <ul>
            <li class="info-item"><strong>نوع المرسل:</strong> 
            <span>{{ userType }}</span>
             </li>
            <li class="info-item"><strong>الإسم الكامل:</strong> <span class="ltr"> {{ fullName }} </span></li>
            <li class="info-item"><strong>رقم الهاتف:</strong> <span class="ltr"> {{ phoneNumber }} </span></li>
            <li class="info-item"><strong>البريد الإلكتروني:</strong> <span class="ltr"> {{ email }} </span></li>
            <li class="info-item"><strong>نوع الرسالة:</strong> {{ contentType }} </li>
            <li class="info-item content">
                <div class="content-title">محتوى الرسالة:</div>
                <span class="content-text">{{ content }}</span>
            </li>
        </ul>
    </div>
</body>
</html>
`;
